Applications permettant de visualiser les données de transport en commun (dossier app_tc) :
- test_app_simple.R : sélecteurs ville et date seulement
- test_app.R : + sélecteurs de la période
- test_app_symbo.R : + symbologie couleur
- test_app_symbo_tc : + sélecteur du type de transport en commun

Applications permettant de visualiser les données de VLS (dossier app_vls) :
- flux_vls : représentation des flux sans la symbologie couleur
- flux_vls_couleur : + symbologie couleur
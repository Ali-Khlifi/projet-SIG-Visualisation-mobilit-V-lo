R_flux_sans_couleur : Représentation de flux VLS sur R sans la symbologie couleur
R_flux_couluer : Ajout de la symbologie couleur